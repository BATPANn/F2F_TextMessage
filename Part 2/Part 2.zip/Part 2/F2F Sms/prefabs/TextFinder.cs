using TMPro;
using UnityEngine;

public class TextFinder : MonoBehaviour
{


    public TextMeshProUGUI Text_Child;


}
