using UnityEngine;
using TMPro;

public class F2F_Sms_TmproRefrence : MonoBehaviour
{


    public TextMeshProUGUI Text_Refrence;

}
